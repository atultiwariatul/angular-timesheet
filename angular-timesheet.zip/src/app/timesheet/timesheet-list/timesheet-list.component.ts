import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timesheet-list',
  templateUrl: './timesheet-list.component.html',
  styleUrls: ['./timesheet-list.component.scss']
})
export class TimesheetListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
