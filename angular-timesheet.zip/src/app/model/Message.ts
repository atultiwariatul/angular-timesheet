import {Employee} from './employee';

export class Message {
  employee: Employee;
  messageText: string;
  read: boolean;
}
