import {Employee} from './employee';

export class Project {
  id: number;
  projectName: string;
  startDate: any;
  endDate: any;
  employee: Employee;
}
