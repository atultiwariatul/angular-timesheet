export class Daysheet {
  id: number;
  date: number;
  hour: number;
}
